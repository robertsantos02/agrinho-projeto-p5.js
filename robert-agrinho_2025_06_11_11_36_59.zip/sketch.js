let frutas = []; // Array para armazenar as frutas

function setup() {
  createCanvas(800, 400); // Tela dividida entre campo e cidade
  // Inicializa algumas frutas no campo
  for (let i = 0; i < 5; i++) {
    frutas.push(new Fruta(random(100, width / 2 - 50), random(150, height - 100)));
  }
}

function draw() {
  // Desenha o cenário do campo (lado esquerdo)
  background(135, 206, 235); // Céu azul
  fill(107, 142, 35); // Grama
  rect(0, height * 0.6, width / 2, height * 0.4);

  // Desenha árvores frutíferas
  drawArvores();

  // Desenha o cenário da cidade (lado direito)
  fill(150); // Fundo da cidade
  rect(width / 2, 0, width / 2, height);
  drawPredios();
  drawBarracaFeira();

  // Atualiza e exibe as frutas
  for (let i = 0; i < frutas.length; i++) {
    frutas[i].mover();
    frutas[i].exibir();
  }
}

// Classe para a Fruta
class Fruta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 0; // Começa pequena
    this.caindo = false;
    this.velocidadeQueda = 0;
    this.chegouNaFeira = false;
    this.tipo = floor(random(3)); // 0: Maçã, 1: Laranja, 2: Banana
  }

  mover() {
    // Lógica de crescimento
    if (this.tamanho < 30 && !this.caindo) {
      this.tamanho += 0.5;
    }

    // Lógica de queda
    if (this.caindo) {
      this.y += this.velocidadeQueda;
      this.velocidadeQueda += 0.1; // Gravidade
      if (this.y > height * 0.7 && this.x < width / 2) { // Tocou o chão do campo
        this.caindo = false;
        // Inicia o movimento para a feira
        this.alvoX = random(width / 2 + 50, width - 50); // Posição na feira
        this.alvoY = height * 0.8;
      }
    }

    // Lógica de movimento para a feira
    if (!this.caindo && this.x < width - 20 && this.x > width / 2 - 100 && !this.chegouNaFeira) {
        this.x = lerp(this.x, this.alvoX, 0.02);
        this.y = lerp(this.y, this.alvoY, 0.02);
        if (dist(this.x, this.y, this.alvoX, this.alvoY) < 5) {
            this.chegouNaFeira = true;
        }
    }

    // Exemplo de quando a fruta deve cair
    if (this.tamanho >= 30 && random(1) < 0.005 && !this.caindo) { // Chance de cair
        this.caindo = true;
    }
  }

  exibir() {
    push();
    translate(this.x, this.y);
    noStroke();
    if (this.tipo === 0) { // Maçã
      fill(255, 0, 0);
      ellipse(0, 0, this.tamanho, this.tamanho);
    } else if (this.tipo === 1) { // Laranja
      fill(255, 165, 0);
      ellipse(0, 0, this.tamanho, this.tamanho);
    } else { // Banana
      fill(255, 255, 0);
      arc(0, 0, this.tamanho * 1.5, this.tamanho, PI, TWO_PI); // Forma de banana
    }
    pop();
  }
}

function drawArvores() {
  // Desenha algumas árvores simples no lado do campo
  fill(139, 69, 19); // Tronco
  rect(150, height * 0.4, 20, height * 0.2);
  fill(34, 139, 34); // Folhagem
  ellipse(160, height * 0.35, 100, 100);

  rect(300, height * 0.5, 20, height * 0.15);
  fill(34, 139, 34); // Folhagem
  ellipse(310, height * 0.45, 80, 80);
}

function drawPredios() {
  // Desenha alguns prédios simples no lado da cidade
  fill(100);
  rect(width / 2 + 50, height * 0.3, 80, height * 0.5);
  rect(width / 2 + 150, height * 0.2, 70, height * 0.6);
  fill(120);
  rect(width / 2 + 250, height * 0.4, 90, height * 0.4);
}

function drawBarracaFeira() {
  // Desenha uma barraca de feira simples
  fill(200, 150, 100); // Cor da madeira
  rect(width / 2 + 70, height * 0.75, 250, 20); // Balcão
  rect(width / 2 + 90, height * 0.8, 210, 50); // Parte de baixo
  fill(255, 200, 0); // Teto
  triangle(width / 2 + 70, height * 0.75, width / 2 + 320, height * 0.75, width / 2 + 195, height * 0.6);
}